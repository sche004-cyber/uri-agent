from dataclasses import dataclass, field
from typing import Dict, Optional


@dataclass
class SessionState:
    """
    Stores the active URI conversation state.

    The controller owns workflow state.
    AI models do not directly control this state.
    """

    session_id: str

    task: Optional[str] = None

    current_facts: Dict[str, object] = field(
        default_factory=dict
    )

    evidence_facts: Dict[str, object] = field(
        default_factory=dict
    )

    historical_facts: Dict[str, object] = field(
        default_factory=dict
    )

    last_question_field: Optional[str] = None

    clarification_complete: bool = False

    evidence_verification_pending: bool = False

    active_evidence_query: Optional[str] = None

    active_evidence_context: Optional[str] = None


class SessionManager:
    """
    Keeps URI conversation sessions in memory.

    Persistent storage can be added later.
    """

    def __init__(self):
        self.sessions: Dict[str, SessionState] = {}


    def get_session(
        self,
        session_id: str
    ) -> SessionState:

        if session_id not in self.sessions:

            self.sessions[session_id] = (
                SessionState(
                    session_id=session_id
                )
            )

        return self.sessions[session_id]


    def reset_session(
        self,
        session_id: str
    ) -> SessionState:

        self.sessions[session_id] = (
            SessionState(
                session_id=session_id
            )
        )

        return self.sessions[session_id]

